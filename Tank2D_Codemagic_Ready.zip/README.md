# Tank2D — Codemagic ready

Полноценный Xcode-проект для простой 2D-танковки.

Bundle ID: com.tank2d.game

В codemagic.yaml есть:
- ios-native-signed — сборка подписанного .ipa после настройки Apple signing;
- ios-simulator — unsigned .app для iOS Simulator.

Для физического iPhone/iPad нужен подписанный build. Codemagic использует macOS/Xcode для native iOS build.
