import SpriteKit

final class GameScene: SKScene {
    private var player = SKShapeNode(rectOf: CGSize(width: 54, height: 38), cornerRadius: 7)
    private var turret = SKShapeNode(rectOf: CGSize(width: 38, height: 8), cornerRadius: 4)
    private var enemies: [SKShapeNode] = []
    private var bullets: [SKShapeNode] = []
    private var joystickBase = SKShapeNode(circleOfRadius: 65)
    private var joystickKnob = SKShapeNode(circleOfRadius: 30)
    private var fireButton = SKShapeNode(circleOfRadius: 42)
    private var moveVector = CGVector.zero
    private var movingTouch = false
    private var score = 0
    private var hp = 100
    private var lastUpdate: TimeInterval = 0
    private var spawnTimer: TimeInterval = 0
    private var scoreLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
    private var hpLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")

    override func didMove(to view: SKView) {
        backgroundColor = SKColor(red: 0.08, green: 0.11, blue: 0.08, alpha: 1)
        setupArena(); setupPlayer(); setupControls()
        spawnEnemy(); spawnEnemy()
    }

    private func setupArena() {
        let border = SKShapeNode(rectOf: CGSize(width: size.width - 30, height: size.height - 30), cornerRadius: 20)
        border.strokeColor = .gray; border.lineWidth = 3; border.fillColor = .clear; border.zPosition = 1
        addChild(border)
        for _ in 0..<8 {
            let wall = SKShapeNode(rectOf: CGSize(width: CGFloat.random(in: 45...110),
                                                   height: CGFloat.random(in: 25...60)), cornerRadius: 5)
            wall.fillColor = SKColor(white: 0.28, alpha: 1); wall.strokeColor = .darkGray; wall.zPosition = 2
            wall.position = CGPoint(x: CGFloat.random(in: 70...(size.width - 70)),
                                    y: CGFloat.random(in: 150...(size.height - 130)))
            addChild(wall)
        }
    }

    private func setupPlayer() {
        player.fillColor = .systemGreen; player.strokeColor = .black; player.lineWidth = 3
        player.position = CGPoint(x: size.width / 2, y: size.height / 2); player.zPosition = 10
        addChild(player)
        turret.fillColor = .darkGray; turret.strokeColor = .black; turret.position = CGPoint(x: 25, y: 0); turret.zPosition = 11
        player.addChild(turret)
    }

    private func setupControls() {
        joystickBase.fillColor = .white.withAlphaComponent(0.12); joystickBase.strokeColor = .white.withAlphaComponent(0.4)
        joystickBase.lineWidth = 2; joystickBase.position = CGPoint(x: 90, y: 90); joystickBase.zPosition = 100
        addChild(joystickBase)
        joystickKnob.fillColor = .white.withAlphaComponent(0.28); joystickKnob.strokeColor = .white.withAlphaComponent(0.6)
        joystickKnob.position = joystickBase.position; joystickKnob.zPosition = 101; addChild(joystickKnob)

        fireButton.fillColor = .systemRed.withAlphaComponent(0.75); fireButton.strokeColor = .white.withAlphaComponent(0.7)
        fireButton.lineWidth = 2; fireButton.position = CGPoint(x: size.width - 90, y: 90); fireButton.zPosition = 100
        addChild(fireButton)
        let fire = SKLabelNode(fontNamed: "AvenirNext-Bold")
        fire.text = "FIRE"; fire.fontSize = 15; fire.verticalAlignmentMode = .center; fire.zPosition = 101
        fireButton.addChild(fire)

        scoreLabel.fontSize = 20; scoreLabel.horizontalAlignmentMode = .left
        scoreLabel.position = CGPoint(x: 25, y: size.height - 45); scoreLabel.zPosition = 100; addChild(scoreLabel)
        hpLabel.fontSize = 20; hpLabel.horizontalAlignmentMode = .right
        hpLabel.position = CGPoint(x: size.width - 25, y: size.height - 45); hpLabel.zPosition = 100; addChild(hpLabel)
        updateHUD()
    }

    private func updateHUD() {
        scoreLabel.text = "SCORE: \(score)"
        hpLabel.text = "HP: \(hp)"
    }

    private func spawnEnemy() {
        let enemy = SKShapeNode(rectOf: CGSize(width: 50, height: 36), cornerRadius: 7)
        enemy.fillColor = .systemRed; enemy.strokeColor = .black; enemy.lineWidth = 3; enemy.zPosition = 9
        switch Int.random(in: 0...3) {
        case 0: enemy.position = CGPoint(x: CGFloat.random(in: 50...size.width-50), y: size.height-100)
        case 1: enemy.position = CGPoint(x: CGFloat.random(in: 50...size.width-50), y: 100)
        case 2: enemy.position = CGPoint(x: 50, y: CGFloat.random(in: 130...size.height-100))
        default: enemy.position = CGPoint(x: size.width-50, y: CGFloat.random(in: 130...size.height-100))
        }
        addChild(enemy); enemies.append(enemy)
    }

    private func shoot() {
        let bullet = SKShapeNode(circleOfRadius: 6)
        bullet.fillColor = .yellow; bullet.strokeColor = .orange; bullet.position = player.position; bullet.zPosition = 20
        let angle = turret.zRotation
        addChild(bullet); bullets.append(bullet)
        let destination = CGPoint(x: bullet.position.x + cos(angle) * 1300,
                                  y: bullet.position.y + sin(angle) * 1300)
        bullet.run(.sequence([.move(to: destination, duration: 2), .removeFromParent()]))
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let p = touch.location(in: self)
            if fireButton.contains(p) { shoot() }
            else if joystickBase.contains(p) { movingTouch = true; updateJoystick(p) }
            else if p.x > size.width / 2 { aim(at: p) }
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let p = touch.location(in: self)
            if movingTouch { updateJoystick(p) }
            else if p.x > size.width / 2 { aim(at: p) }
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        movingTouch = false; moveVector = .zero; joystickKnob.position = joystickBase.position
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        movingTouch = false; moveVector = .zero; joystickKnob.position = joystickBase.position
    }

    private func updateJoystick(_ point: CGPoint) {
        let dx = point.x - joystickBase.position.x, dy = point.y - joystickBase.position.y
        let distance = max(1, sqrt(dx * dx + dy * dy)), scale = min(1, 65 / distance)
        joystickKnob.position = CGPoint(x: joystickBase.position.x + dx * scale,
                                        y: joystickBase.position.y + dy * scale)
        moveVector = CGVector(dx: dx / distance, dy: dy / distance)
    }

    private func aim(at point: CGPoint) {
        turret.zRotation = atan2(point.y - player.position.y, point.x - player.position.x)
    }

    override func update(_ currentTime: TimeInterval) {
        if lastUpdate == 0 { lastUpdate = currentTime }
        let dt = min(currentTime - lastUpdate, 0.05); lastUpdate = currentTime

        let speed: CGFloat = 180
        player.position.x += moveVector.dx * speed * CGFloat(dt)
        player.position.y += moveVector.dy * speed * CGFloat(dt)
        player.position.x = max(45, min(size.width - 45, player.position.x))
        player.position.y = max(120, min(size.height - 45, player.position.y))

        for enemy in enemies {
            let dx = player.position.x - enemy.position.x, dy = player.position.y - enemy.position.y
            let distance = max(1, sqrt(dx * dx + dy * dy))
            enemy.position.x += dx / distance * 45 * CGFloat(dt)
            enemy.position.y += dy / distance * 45 * CGFloat(dt)
            if distance < 42 {
                hp -= 10
                enemy.position = CGPoint(x: CGFloat.random(in: 50...size.width-50),
                                         y: CGFloat.random(in: 130...size.height-100))
                updateHUD()
                if hp <= 0 { gameOver(); return }
            }
        }

        spawnTimer += dt
        if spawnTimer > 5 && enemies.count < 6 { spawnTimer = 0; spawnEnemy() }
        checkBulletHits()
    }

    private func checkBulletHits() {
        for bullet in bullets where bullet.parent != nil {
            for enemy in enemies where enemy.parent != nil {
                if bullet.frame.intersects(enemy.frame) {
                    bullet.removeFromParent(); enemy.removeFromParent(); score += 100; updateHUD()
                    if let i = bullets.firstIndex(of: bullet) { bullets.remove(at: i) }
                    if let i = enemies.firstIndex(of: enemy) { enemies.remove(at: i) }
                    break
                }
            }
        }
    }

    private func gameOver() {
        isPaused = true
        let overlay = SKShapeNode(rectOf: CGSize(width: size.width, height: size.height))
        overlay.fillColor = .black.withAlphaComponent(0.72); overlay.strokeColor = .clear; overlay.zPosition = 200; addChild(overlay)
        let title = SKLabelNode(fontNamed: "AvenirNext-Bold")
        title.text = "GAME OVER"; title.fontSize = 42; title.position = CGPoint(x: size.width/2, y: size.height/2 + 35); title.zPosition = 201; addChild(title)
        let result = SKLabelNode(fontNamed: "AvenirNext-Bold")
        result.text = "Score: \(score)"; result.fontSize = 24; result.position = CGPoint(x: size.width/2, y: size.height/2 - 10); result.zPosition = 201; addChild(result)
    }
}
