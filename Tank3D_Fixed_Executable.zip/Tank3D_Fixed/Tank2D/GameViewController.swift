import UIKit
import SceneKit

final class GameViewController: UIViewController {
    private let sceneView = SCNView()
    private let scene = SCNScene()
    private let vehicle = SCNNode()
    private var keys = Set<UInt8>()
    private var lastTime: TimeInterval = 0

    override func loadView() {
        view = sceneView
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        sceneView.scene = scene
        sceneView.backgroundColor = .black
        sceneView.allowsCameraControl = false
        sceneView.isPlaying = true
        sceneView.preferredFramesPerSecond = 60
        sceneView.antialiasingMode = .multisampling4X

        buildScene()
        addControls()
    }

    private func buildScene() {
        let floor = SCNNode(geometry: SCNFloor())
        floor.geometry?.firstMaterial?.diffuse.contents = UIColor(white: 0.16, alpha: 1)
        scene.rootNode.addChildNode(floor)

        for x in stride(from: -12.0, through: 12.0, by: 4.0) {
            let block = SCNNode(geometry: SCNBox(width: 1.6, height: 1.2, length: 1.6, chamferRadius: 0.08))
            block.position = SCNVector3(Float(x), 0.6, -8)
            block.geometry?.firstMaterial?.diffuse.contents = UIColor(white: 0.32, alpha: 1)
            scene.rootNode.addChildNode(block)
        }

        let body = SCNNode(geometry: SCNBox(width: 2.2, height: 0.55, length: 3.0, chamferRadius: 0.12))
        body.position.y = 0.65
        body.geometry?.firstMaterial?.diffuse.contents = UIColor.systemGreen
        vehicle.addChildNode(body)

        let cabin = SCNNode(geometry: SCNBox(width: 1.55, height: 0.45, length: 1.5, chamferRadius: 0.1))
        cabin.position = SCNVector3(0, 1.1, -0.15)
        cabin.geometry?.firstMaterial?.diffuse.contents = UIColor.darkGray
        vehicle.addChildNode(cabin)

        for x in [-0.95, 0.95] {
            for z in [-0.9, 0.9] {
                let wheel = SCNNode(geometry: SCNCylinder(radius: 0.38, height: 0.28))
                wheel.rotation = SCNVector4(1, 0, 0, Float.pi / 2)
                wheel.position = SCNVector3(Float(x), 0.42, Float(z))
                wheel.geometry?.firstMaterial?.diffuse.contents = UIColor.black
                vehicle.addChildNode(wheel)
            }
        }

        vehicle.position = SCNVector3(0, 0, 3)
        scene.rootNode.addChildNode(vehicle)

        let camera = SCNNode()
        camera.camera = SCNCamera()
        camera.camera?.fieldOfView = 65
        camera.position = SCNVector3(0, 5.5, 8)
        camera.eulerAngles.x = -.45
        vehicle.addChildNode(camera)

        let light = SCNNode()
        light.light = SCNLight()
        light.light?.type = .omni
        light.light?.intensity = 1300
        light.position = SCNVector3(0, 8, 4)
        scene.rootNode.addChildNode(light)

        let ambient = SCNNode()
        ambient.light = SCNLight()
        ambient.light?.type = .ambient
        ambient.light?.intensity = 500
        scene.rootNode.addChildNode(ambient)
    }

    private func addControls() {
        let hint = UILabel()
        hint.text = "3D VEHICLE DEMO  •  Drag to move"
        hint.textColor = .white
        hint.font = .systemFont(ofSize: 14, weight: .semibold)
        hint.translatesAutoresizingMaskIntoConstraints = false
        sceneView.addSubview(hint)
        NSLayoutConstraint.activate([
            hint.topAnchor.constraint(equalTo: sceneView.safeAreaLayoutGuide.topAnchor, constant: 14),
            hint.centerXAnchor.constraint(equalTo: sceneView.centerXAnchor)
        ])

        let pad = UIView()
        pad.backgroundColor = UIColor.white.withAlphaComponent(0.10)
        pad.layer.cornerRadius = 65
        pad.translatesAutoresizingMaskIntoConstraints = false
        sceneView.addSubview(pad)
        NSLayoutConstraint.activate([
            pad.leadingAnchor.constraint(equalTo: sceneView.leadingAnchor, constant: 24),
            pad.bottomAnchor.constraint(equalTo: sceneView.safeAreaLayoutGuide.bottomAnchor, constant: -24),
            pad.widthAnchor.constraint(equalToConstant: 130),
            pad.heightAnchor.constraint(equalToConstant: 130)
        ])

        let knob = UIView()
        knob.backgroundColor = UIColor.white.withAlphaComponent(0.75)
        knob.layer.cornerRadius = 28
        knob.translatesAutoresizingMaskIntoConstraints = false
        pad.addSubview(knob)
        NSLayoutConstraint.activate([
            knob.centerXAnchor.constraint(equalTo: pad.centerXAnchor),
            knob.centerYAnchor.constraint(equalTo: pad.centerYAnchor),
            knob.widthAnchor.constraint(equalToConstant: 56),
            knob.heightAnchor.constraint(equalToConstant: 56)
        ])

        let pan = UIPanGestureRecognizer(target: self, action: #selector(handlePad(_:)))
        pad.addGestureRecognizer(pan)
    }

    @objc private func handlePad(_ gesture: UIPanGestureRecognizer) {
        guard let pad = gesture.view else { return }
        let p = gesture.translation(in: pad)
        let radius: CGFloat = 42
        let dx = max(-radius, min(radius, p.x))
        let dy = max(-radius, min(radius, p.y))

        if gesture.state == .ended || gesture.state == .cancelled {
            moveVehicle(dx: 0, dy: 0)
        } else {
            moveVehicle(dx: dx / radius, dy: dy / radius)
        }
    }

    private func moveVehicle(dx: CGFloat, dy: CGFloat) {
        let speed: Float = 0.12
        vehicle.position.x += Float(dx) * speed
        vehicle.position.z += Float(dy) * speed

        if abs(dx) + abs(dy) > 0.05 {
            vehicle.eulerAngles.y = atan2(Float(dx), Float(dy))
        }
    }
}
