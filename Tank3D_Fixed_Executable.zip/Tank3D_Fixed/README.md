# Tank3D — fixed executable build

This version fixes the previous IPA packaging problem where `App.app` did not contain its `Tank2D` bundle executable.

Important build settings:
- PRODUCT_NAME = Tank2D
- EXECUTABLE_NAME = Tank2D
- CFBundleExecutable = Tank2D
- INFOPLIST_FILE = Tank2D/Info.plist
- GENERATE_INFOPLIST_FILE = NO
- SceneKit.framework is explicitly linked

The app is a small SceneKit 3D vehicle demo. Build the `ios-native-signed` workflow in Codemagic and use the resulting IPA.
