# Tank3D — verified executable build

This version intentionally uses a minimal UIKit + SceneKit app and an explicit archive/export pipeline.
The Codemagic workflow stops with an error if the final `.app` does not contain the `Tank3D` executable.

Use the `ios-native-signed` workflow and download the IPA from the `ipa/` artifact.
