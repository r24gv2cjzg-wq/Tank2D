import UIKit
import SceneKit

final class GameViewController: UIViewController {
    private let sceneView = SCNView()
    private let scene = SCNScene()
    private let vehicle = SCNNode()
    private var timer: CADisplayLink?
    private var forward = false
    private var backward = false
    private var left = false
    private var right = false

    override func loadView() { view = sceneView }
    override func viewDidLoad() {
        super.viewDidLoad()
        sceneView.scene = scene
        sceneView.backgroundColor = UIColor(red: 0.06, green: 0.07, blue: 0.09, alpha: 1)
        sceneView.preferredFramesPerSecond = 60
        sceneView.autoenablesDefaultLighting = true
        buildScene()
        buildControls()
        timer = CADisplayLink(target: self, selector: #selector(step))
        timer?.add(to: .main, forMode: .common)
    }
    deinit { timer?.invalidate() }

    private func buildScene() {
        let floor = SCNNode(geometry: SCNFloor())
        floor.geometry?.firstMaterial?.diffuse.contents = UIColor(white: 0.18, alpha: 1)
        scene.rootNode.addChildNode(floor)
        let camera = SCNNode()
        camera.camera = SCNCamera()
        camera.position = SCNVector3(0, 8, 10)
        camera.eulerAngles = SCNVector3(-0.62, 0, 0)
        scene.rootNode.addChildNode(camera)
        sceneView.pointOfView = camera

        let body = SCNNode(geometry: SCNBox(width: 2.2, height: 0.65, length: 3.0, chamferRadius: 0.12))
        body.position.y = 0.65
        body.geometry?.firstMaterial?.diffuse.contents = UIColor.systemGreen
        vehicle.addChildNode(body)
        let cabin = SCNNode(geometry: SCNBox(width: 1.45, height: 0.5, length: 1.4, chamferRadius: 0.1))
        cabin.position = SCNVector3(0, 1.2, 0)
        cabin.geometry?.firstMaterial?.diffuse.contents = UIColor.darkGray
        vehicle.addChildNode(cabin)
        scene.rootNode.addChildNode(vehicle)
    }

    private func buildControls() {
        let buttons: [(String, Selector, CGFloat, CGFloat)] = [
            ("▲", #selector(goForward), 0, 0), ("▼", #selector(goBackward), 0, 1),
            ("◀", #selector(turnLeft), 1, 1), ("▶", #selector(turnRight), 2, 1)
        ]
        for (title, action, x, y) in buttons {
            let b = UIButton(type: .system)
            b.setTitle(title, for: .normal)
            b.titleLabel?.font = .systemFont(ofSize: 25, weight: .bold)
            b.backgroundColor = UIColor.white.withAlphaComponent(0.16)
            b.layer.cornerRadius = 16
            b.frame = CGRect(x: 20 + x * 68, y: view.bounds.height - 145 + y * 62, width: 58, height: 52)
            b.autoresizingMask = [.flexibleTopMargin, .flexibleRightMargin]
            b.addTarget(self, action: action, for: .touchUpInside)
            view.addSubview(b)
        }
    }
    @objc private func goForward() { vehicle.position.z -= 0.7 }
    @objc private func goBackward() { vehicle.position.z += 0.7 }
    @objc private func turnLeft() { vehicle.eulerAngles.y += 0.15 }
    @objc private func turnRight() { vehicle.eulerAngles.y -= 0.15 }
    @objc private func step() { }
}
