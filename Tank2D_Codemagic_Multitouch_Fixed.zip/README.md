# Tank2D — Codemagic build

This version adds:
- Tank rotates toward the direction of movement.
- Turret always points forward with the tank.
- Movement and FIRE support multitouch simultaneously.
- Holding FIRE continuously shoots.

Build the iOS Simulator workflow in Codemagic if you are using LiveContainer.

This revision explicitly enables UIKit/SpriteKit multitouch so the joystick and FIRE button can be held simultaneously.
