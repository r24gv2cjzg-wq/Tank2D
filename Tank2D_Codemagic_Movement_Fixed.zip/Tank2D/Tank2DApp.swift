import SwiftUI
import SpriteKit

@main
struct Tank2DApp: App {
    var body: some Scene {
        WindowGroup { GameView().ignoresSafeArea() }
    }
}
