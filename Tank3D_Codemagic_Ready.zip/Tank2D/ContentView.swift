import SwiftUI
import UIKit

struct GameView: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> Tank3DController {
        Tank3DController()
    }

    func updateUIViewController(
        _ uiViewController: Tank3DController,
        context: Context
    ) {}
}
