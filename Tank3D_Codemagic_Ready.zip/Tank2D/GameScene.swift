import UIKit
import SceneKit

final class JoystickView: UIView {
    var vectorChanged: ((CGVector) -> Void)?
    private var knob = UIView()
    private let radius: CGFloat = 55
    private var activeTouch: UITouch?

    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        commonInit()
    }

    private func commonInit() {
        isMultipleTouchEnabled = true
        backgroundColor = UIColor.white.withAlphaComponent(0.12)
        layer.cornerRadius = 65
        layer.borderWidth = 2
        layer.borderColor = UIColor.white.withAlphaComponent(0.35).cgColor

        knob.frame = CGRect(x: 40, y: 40, width: 50, height: 50)
        knob.backgroundColor = UIColor.white.withAlphaComponent(0.28)
        knob.layer.cornerRadius = 25
        knob.isUserInteractionEnabled = false
        addSubview(knob)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        if activeTouch == nil {
            knob.center = CGPoint(x: bounds.midX, y: bounds.midY)
        }
    }

    private func update(_ point: CGPoint) {
        let center = CGPoint(x: bounds.midX, y: bounds.midY)
        let dx = point.x - center.x
        let dy = point.y - center.y
        let distance = max(1, hypot(dx, dy))
        let scale = min(1, radius / distance)

        let x = dx * scale
        let y = dy * scale

        knob.center = CGPoint(x: center.x + x, y: center.y + y)
        vectorChanged?(CGVector(dx: x / radius, dy: -y / radius))
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard activeTouch == nil, let touch = touches.first else { return }
        activeTouch = touch
        update(touch.location(in: self))
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let activeTouch else { return }
        for touch in touches where touch === activeTouch {
            update(touch.location(in: self))
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        end(touches)
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        end(touches)
    }

    private func end(_ touches: Set<UITouch>) {
        guard let activeTouch else { return }

        if touches.contains(activeTouch) {
            self.activeTouch = nil
            knob.center = CGPoint(x: bounds.midX, y: bounds.midY)
            vectorChanged?(.zero)
        }
    }
}

final class Tank3DController: UIViewController, SCNSceneRendererDelegate {
    private let scnView = SCNView()
    private let tank = SCNNode()
    private let turret = SCNNode()

    private var enemies: [SCNNode] = []
    private var bullets: [(node: SCNNode, velocity: SCNVector3)] = []

    private var moveVector = CGVector.zero
    private var firing = false
    private var fireCooldown: TimeInterval = 0
    private var lastTime: TimeInterval = 0
    private var spawnTimer: TimeInterval = 0

    private var hp = 100
    private var score = 0

    private let scoreLabel = UILabel()
    private let hpLabel = UILabel()
    private let fireButton = UIButton(type: .system)
    private let joystick = JoystickView(frame: .zero)

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .black
        view.isMultipleTouchEnabled = true

        setupScene()
        setupHUD()
        setupTank()

        for _ in 0..<3 {
            spawnEnemy()
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        let width = view.bounds.width
        let height = view.bounds.height

        joystick.frame = CGRect(
            x: 25,
            y: height - 165,
            width: 130,
            height: 130
        )

        fireButton.frame = CGRect(
            x: width - 125,
            y: height - 150,
            width: 100,
            height: 100
        )

        scoreLabel.frame = CGRect(
            x: 20,
            y: view.safeAreaInsets.top + 8,
            width: 160,
            height: 30
        )

        hpLabel.frame = CGRect(
            x: width - 180,
            y: view.safeAreaInsets.top + 8,
            width: 160,
            height: 30
        )
    }

    private func setupScene() {
        scnView.frame = view.bounds
        scnView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        scnView.allowsCameraControl = false
        scnView.isMultipleTouchEnabled = true
        scnView.backgroundColor = UIColor(
            red: 0.08,
            green: 0.12,
            blue: 0.08,
            alpha: 1
        )

        let scene = SCNScene()
        scnView.scene = scene
        scene.rendererDelegate = self

        view.insertSubview(scnView, at: 0)

        scene.rootNode.addChildNode(makeGround())

        let camera = SCNCamera()
        camera.fieldOfView = 65

        let cameraNode = SCNNode()
        cameraNode.camera = camera
        cameraNode.position = SCNVector3(0, 7.5, 10)
        scene.rootNode.addChildNode(cameraNode)
        scnView.pointOfView = cameraNode

        let light = SCNLight()
        light.type = .omni
        light.intensity = 1300

        let lightNode = SCNNode()
        lightNode.light = light
        lightNode.position = SCNVector3(0, 10, 5)
        scene.rootNode.addChildNode(lightNode)

        let ambient = SCNLight()
        ambient.type = .ambient
        ambient.intensity = 450

        let ambientNode = SCNNode()
        ambientNode.light = ambient
        scene.rootNode.addChildNode(ambientNode)

        // Simple arena walls.
        for z in stride(from: -18.0, through: 18.0, by: 6.0) {
            addWall(at: SCNVector3(-12, 0.75, Float(z)))
            addWall(at: SCNVector3(12, 0.75, Float(z)))
        }

        for x in stride(from: -6.0, through: 6.0, by: 6.0) {
            addWall(at: SCNVector3(Float(x), 0.75, -18))
            addWall(at: SCNVector3(Float(x), 0.75, 18))
        }
    }

    private func makeGround() -> SCNNode {
        let plane = SCNPlane(width: 40, height: 40)
        plane.firstMaterial?.diffuse.contents = UIColor(
            red: 0.20,
            green: 0.25,
            blue: 0.16,
            alpha: 1
        )
        plane.firstMaterial?.roughness.contents = 1.0

        let node = SCNNode(geometry: plane)
        node.eulerAngles.x = -.pi / 2
        return node
    }

    private func addWall(at position: SCNVector3) {
        let box = SCNBox(
            width: 3,
            height: 1.5,
            length: 3,
            chamferRadius: 0.15
        )
        box.firstMaterial?.diffuse.contents = UIColor.darkGray

        let node = SCNNode(geometry: box)
        node.position = position
        scnView.scene?.rootNode.addChildNode(node)
    }

    private func setupTank() {
        tank.name = "playerTank"
        tank.position = SCNVector3(0, 0.55, 0)

        let body = SCNBox(
            width: 1.8,
            height: 0.65,
            length: 2.4,
            chamferRadius: 0.12
        )
        body.firstMaterial?.diffuse.contents = UIColor.systemGreen

        let bodyNode = SCNNode(geometry: body)
        tank.addChildNode(bodyNode)

        for x in [-1.0, 1.0] {
            let track = SCNBox(
                width: 0.35,
                height: 0.5,
                length: 2.6,
                chamferRadius: 0.05
            )
            track.firstMaterial?.diffuse.contents = UIColor(
                white: 0.12,
                alpha: 1
            )

            let trackNode = SCNNode(geometry: track)
            trackNode.position = SCNVector3(Float(x), -0.08, 0)
            tank.addChildNode(trackNode)
        }

        let turretBase = SCNCylinder(radius: 0.62, height: 0.28)
        turretBase.firstMaterial?.diffuse.contents = UIColor.systemGreen

        let turretBaseNode = SCNNode(geometry: turretBase)
        turretBaseNode.position.y = 0.45
        turret.addChildNode(turretBaseNode)

        let barrel = SCNBox(
            width: 0.22,
            height: 0.22,
            length: 1.8,
            chamferRadius: 0.04
        )
        barrel.firstMaterial?.diffuse.contents = UIColor.darkGray

        let barrelNode = SCNNode(geometry: barrel)
        barrelNode.position = SCNVector3(0, 0.47, -0.85)
        turret.addChildNode(barrelNode)

        tank.addChildNode(turret)
        scnView.scene?.rootNode.addChildNode(tank)
    }

    private func spawnEnemy() {
        let enemy = SCNNode()
        enemy.name = "enemy"

        let body = SCNBox(
            width: 1.7,
            height: 0.65,
            length: 2.2,
            chamferRadius: 0.12
        )
        body.firstMaterial?.diffuse.contents = UIColor.systemRed
        enemy.addChildNode(SCNNode(geometry: body))

        let base = SCNCylinder(radius: 0.58, height: 0.25)
        base.firstMaterial?.diffuse.contents = UIColor.systemRed

        let baseNode = SCNNode(geometry: base)
        baseNode.position.y = 0.45
        enemy.addChildNode(baseNode)

        let barrel = SCNBox(
            width: 0.2,
            height: 0.2,
            length: 1.5,
            chamferRadius: 0.03
        )
        barrel.firstMaterial?.diffuse.contents = UIColor.darkGray

        let barrelNode = SCNNode(geometry: barrel)
        barrelNode.position = SCNVector3(0, 0.45, -0.75)
        enemy.addChildNode(barrelNode)

        enemy.position = SCNVector3(
            Float.random(in: -9...9),
            0.55,
            Float.random(in: -14...14)
        )

        scnView.scene?.rootNode.addChildNode(enemy)
        enemies.append(enemy)
    }

    private func setupHUD() {
        scoreLabel.textColor = .white
        scoreLabel.font = .boldSystemFont(ofSize: 20)
        scoreLabel.text = "SCORE: 0"
        view.addSubview(scoreLabel)

        hpLabel.textColor = .white
        hpLabel.font = .boldSystemFont(ofSize: 20)
        hpLabel.text = "HP: 100"
        view.addSubview(hpLabel)

        joystick.vectorChanged = { [weak self] vector in
            self?.moveVector = vector
        }
        view.addSubview(joystick)

        fireButton.setTitle("FIRE", for: .normal)
        fireButton.setTitleColor(.white, for: .normal)
        fireButton.titleLabel?.font = .boldSystemFont(ofSize: 15)
        fireButton.backgroundColor = UIColor.systemRed.withAlphaComponent(0.75)
        fireButton.layer.cornerRadius = 50
        fireButton.layer.borderWidth = 2
        fireButton.layer.borderColor = UIColor.white.withAlphaComponent(0.7).cgColor

        fireButton.addTarget(
            self,
            action: #selector(fireDown),
            for: [.touchDown]
        )

        fireButton.addTarget(
            self,
            action: #selector(fireUp),
            for: [.touchUpInside, .touchUpOutside, .touchCancel, .touchDragExit]
        )

        view.addSubview(fireButton)
    }

    @objc private func fireDown() {
        firing = true

        if fireCooldown <= 0 {
            shoot()
            fireCooldown = 0.25
        }
    }

    @objc private func fireUp() {
        firing = false
    }

    private func shoot() {
        let sphere = SCNSphere(radius: 0.13)
        sphere.firstMaterial?.diffuse.contents = UIColor.yellow
        sphere.firstMaterial?.emission.contents = UIColor.orange

        let bullet = SCNNode(geometry: sphere)

        // Tank's local -Z axis is its forward direction.
        let forward = SCNVector3(
            -sin(tank.eulerAngles.y),
            0,
            -cos(tank.eulerAngles.y)
        )

        bullet.position = add(
            tank.position,
            add(
                multiply(forward, 1.8),
                SCNVector3(0, 0.65, 0)
            )
        )

        scnView.scene?.rootNode.addChildNode(bullet)
        bullets.append((bullet, multiply(forward, 14)))
    }

    func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        if lastTime == 0 {
            lastTime = time
        }

        let dt = min(time - lastTime, 0.05)
        lastTime = time

        let dx = Float(moveVector.dx)
        let dz = Float(-moveVector.dy)
        let length = hypot(dx, dz)
        let speed: Float = 5.0

        if length > 0.08 {
            let nx = dx / length
            let nz = dz / length

            tank.position.x += nx * speed * Float(dt)
            tank.position.z += nz * speed * Float(dt)

            // Tank faces the direction of movement.
            tank.eulerAngles.y = atan2(nx, nz)

            // Turret is currently locked forward with the hull.
            turret.eulerAngles.y = 0
        }

        tank.position.x = max(-10, min(10, tank.position.x))
        tank.position.z = max(-16, min(16, tank.position.z))

        if fireCooldown > 0 {
            fireCooldown -= dt
        }

        if firing && fireCooldown <= 0 {
            shoot()
            fireCooldown = 0.25
        }

        updateBullets(dt)
        updateEnemies(dt)
        updateCamera()

        spawnTimer += dt

        if spawnTimer > 5 && enemies.count < 5 {
            spawnTimer = 0
            spawnEnemy()
        }
    }

    private func updateBullets(_ dt: TimeInterval) {
        for index in bullets.indices.reversed() {
            let item = bullets[index]

            item.node.position = add(
                item.node.position,
                multiply(item.velocity, Float(dt))
            )

            var remove = false

            for enemyIndex in enemies.indices.reversed() {
                let enemy = enemies[enemyIndex]

                if distance(item.node.position, enemy.position) < 1.1 {
                    enemy.removeFromParentNode()
                    enemies.remove(at: enemyIndex)

                    score += 100
                    scoreLabel.text = "SCORE: \(score)"

                    remove = true
                    break
                }
            }

            if abs(item.node.position.x) > 22 ||
               abs(item.node.position.z) > 22 {
                remove = true
            }

            if remove {
                item.node.removeFromParentNode()
                bullets.remove(at: index)
            }
        }
    }

    private func updateEnemies(_ dt: TimeInterval) {
        for enemy in enemies {
            let dx = tank.position.x - enemy.position.x
            let dz = tank.position.z - enemy.position.z
            let dist = max(0.01, hypot(dx, dz))

            let nx = dx / dist
            let nz = dz / dist

            enemy.position.x += nx * 1.2 * Float(dt)
            enemy.position.z += nz * 1.2 * Float(dt)
            enemy.eulerAngles.y = atan2(nx, nz)

            if dist < 1.5 {
                hp -= 20
                hpLabel.text = "HP: \(max(0, hp))"

                enemy.position = SCNVector3(
                    Float.random(in: -9...9),
                    0.55,
                    Float.random(in: -14...14)
                )

                if hp <= 0 {
                    gameOver()
                    return
                }
            }
        }
    }

    private func updateCamera() {
        guard let camera = scnView.pointOfView else { return }

        let angle = tank.eulerAngles.y
        let distanceBehind: Float = 9

        // Camera stays behind the tank.
        let target = SCNVector3(
            tank.position.x + sin(angle) * distanceBehind,
            tank.position.y + 6.5,
            tank.position.z + cos(angle) * distanceBehind
        )

        camera.position = add(
            camera.position,
            multiply(
                subtract(target, camera.position),
                0.12
            )
        )

        camera.look(at: add(tank.position, SCNVector3(0, 0.8, 0)))
    }

    private func gameOver() {
        firing = false
        moveVector = .zero
        hp = 100
        score = 0

        hpLabel.text = "HP: 100"
        scoreLabel.text = "SCORE: 0"

        tank.position = SCNVector3(0, 0.55, 0)

        for enemy in enemies {
            enemy.removeFromParentNode()
        }

        enemies.removeAll()

        for bullet in bullets {
            bullet.node.removeFromParentNode()
        }

        bullets.removeAll()

        for _ in 0..<3 {
            spawnEnemy()
        }
    }

    // MARK: - Small SCNVector3 helpers

    private func add(_ a: SCNVector3, _ b: SCNVector3) -> SCNVector3 {
        SCNVector3(a.x + b.x, a.y + b.y, a.z + b.z)
    }

    private func subtract(_ a: SCNVector3, _ b: SCNVector3) -> SCNVector3 {
        SCNVector3(a.x - b.x, a.y - b.y, a.z - b.z)
    }

    private func multiply(_ vector: SCNVector3, _ value: Float) -> SCNVector3 {
        SCNVector3(vector.x * value, vector.y * value, vector.z * value)
    }

    private func distance(_ a: SCNVector3, _ b: SCNVector3) -> Float {
        hypot(a.x - b.x, hypot(a.y - b.y, a.z - b.z))
    }
}
