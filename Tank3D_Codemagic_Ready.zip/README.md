# Tank3D — simple iOS prototype

This is the first simple 3D version of Tank2D, now using SceneKit.

Features:
- 3D tank made from simple geometric shapes
- Third-person camera following the tank
- Virtual movement joystick
- Tank rotates toward its movement direction
- FIRE button with continuous shooting
- Multitouch: movement + FIRE at the same time
- Simple red enemy tanks that chase the player
- Bullets, HP and score
- Simple 3D arena with walls

Build with the same Codemagic setup as the previous project.
For LiveContainer, use the iOS Simulator/unsigned artifact workflow as before.
