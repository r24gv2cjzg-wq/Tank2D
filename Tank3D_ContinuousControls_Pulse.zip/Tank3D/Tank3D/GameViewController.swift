import UIKit
import SceneKit

final class GameViewController: UIViewController {
    private let sceneView = SCNView()
    private let scene = SCNScene()
    private let vehicle = SCNNode()
    private let camera = SCNNode()
    private var displayLink: CADisplayLink?

    // Continuous input state. Buttons set these on touch-down and clear them on release/cancel.
    private var moveForward = false
    private var moveBackward = false
    private var turnLeft = false
    private var turnRight = false
    private var pulseRequested = false

    private let speed: Float = 3.2
    private let turnSpeed: Float = 2.2

    override func loadView() { view = sceneView }

    override func viewDidLoad() {
        super.viewDidLoad()
        sceneView.scene = scene
        sceneView.backgroundColor = UIColor(red: 0.055, green: 0.07, blue: 0.09, alpha: 1)
        sceneView.preferredFramesPerSecond = 60
        sceneView.autoenablesDefaultLighting = true
        sceneView.isPlaying = true
        sceneView.allowsCameraControl = false

        buildScene()
        buildControls()

        displayLink = CADisplayLink(target: self, selector: #selector(update))
        displayLink?.add(to: .main, forMode: .common)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        layoutControls()
    }

    deinit { displayLink?.invalidate() }

    private func buildScene() {
        // Ground
        let floor = SCNNode(geometry: SCNPlane(width: 80, height: 80))
        floor.eulerAngles.x = -.pi / 2
        floor.geometry?.firstMaterial?.diffuse.contents = UIColor(red: 0.16, green: 0.18, blue: 0.17, alpha: 1)
        floor.geometry?.firstMaterial?.roughness.contents = 1.0
        scene.rootNode.addChildNode(floor)

        // Simple grid-like road markings / decorative blocks.
        for i in -4...4 {
            let block = SCNNode(geometry: SCNBox(width: 2.2, height: 1.0, length: 2.2, chamferRadius: 0.12))
            block.position = SCNVector3(Float(i) * 6.0, 0.5, Float((i % 2 == 0 ? 1 : -1)) * 9.0)
            block.geometry?.firstMaterial?.diffuse.contents = UIColor(red: 0.28, green: 0.29, blue: 0.30, alpha: 1)
            scene.rootNode.addChildNode(block)
        }

        // Vehicle body.
        let body = SCNNode(geometry: SCNBox(width: 2.2, height: 0.65, length: 3.0, chamferRadius: 0.14))
        body.position.y = 0.65
        body.geometry?.firstMaterial?.diffuse.contents = UIColor.systemGreen
        vehicle.addChildNode(body)

        let cabin = SCNNode(geometry: SCNBox(width: 1.45, height: 0.55, length: 1.4, chamferRadius: 0.12))
        cabin.position = SCNVector3(0, 1.15, 0)
        cabin.geometry?.firstMaterial?.diffuse.contents = UIColor.darkGray
        vehicle.addChildNode(cabin)

        // Wheels/tracks as simple visual elements.
        for x in [-1.05 as Float, 1.05] {
            let track = SCNNode(geometry: SCNBox(width: 0.28, height: 0.42, length: 2.7, chamferRadius: 0.08))
            track.position = SCNVector3(x, 0.42, 0)
            track.geometry?.firstMaterial?.diffuse.contents = UIColor.black
            vehicle.addChildNode(track)
        }

        vehicle.position = SCNVector3(0, 0, 0)
        scene.rootNode.addChildNode(vehicle)

        // Camera follows behind the vehicle.
        camera.camera = SCNCamera()
        camera.camera?.fieldOfView = 62
        scene.rootNode.addChildNode(camera)
        sceneView.pointOfView = camera
        updateCamera(snap: true)

        // Soft lighting.
        let light = SCNNode()
        light.light = SCNLight()
        light.light?.type = .omni
        light.light?.intensity = 1100
        light.position = SCNVector3(0, 12, 4)
        scene.rootNode.addChildNode(light)

        let ambient = SCNNode()
        ambient.light = SCNLight()
        ambient.light?.type = .ambient
        ambient.light?.intensity = 450
        ambient.light?.color = UIColor(white: 0.8, alpha: 1)
        scene.rootNode.addChildNode(ambient)
    }

    private func buildControls() {
        let definitions: [(String, Selector)] = [
            ("▲", #selector(forwardDown)),
            ("▼", #selector(backwardDown)),
            ("◀", #selector(leftDown)),
            ("▶", #selector(rightDown)),
            ("✦", #selector(pulseDown))
        ]

        for (title, downAction) in definitions {
            let button = UIButton(type: .system)
            button.setTitle(title, for: .normal)
            button.titleLabel?.font = .systemFont(ofSize: 27, weight: .bold)
            button.setTitleColor(.white, for: .normal)
            button.backgroundColor = UIColor.white.withAlphaComponent(0.17)
            if title == "✦" {
                button.backgroundColor = UIColor.systemBlue.withAlphaComponent(0.35)
            }
            button.layer.cornerRadius = 18
            button.layer.borderWidth = 1
            button.layer.borderColor = UIColor.white.withAlphaComponent(0.15).cgColor
            button.tag = controls.count
            button.addTarget(self, action: downAction, for: .touchDown)
            button.addTarget(self, action: #selector(controlUp(_:)), for: [.touchUpInside, .touchUpOutside, .touchCancel])
            button.isExclusiveTouch = false
            view.addSubview(button)
            controls.append(button)
        }
    }

    private var controls: [UIButton] = []

    private func layoutControls() {
        guard controls.count == 5 else { return }
        let size: CGFloat = 62
        let gap: CGFloat = 10
        let bottom: CGFloat = view.safeAreaInsets.bottom + 18
        let left: CGFloat = 20
        controls[0].frame = CGRect(x: left + size + gap, y: view.bounds.height - bottom - size * 2 - gap, width: size, height: size)
        controls[1].frame = CGRect(x: left + size + gap, y: view.bounds.height - bottom - size, width: size, height: size)
        controls[2].frame = CGRect(x: left, y: view.bounds.height - bottom - size, width: size, height: size)
        controls[3].frame = CGRect(x: left + (size + gap) * 2, y: view.bounds.height - bottom - size, width: size, height: size)
        controls[4].frame = CGRect(x: view.bounds.width - 88, y: view.bounds.height - bottom - 88, width: 68, height: 68)
    }

    @objc private func forwardDown() { moveForward = true }
    @objc private func backwardDown() { moveBackward = true }
    @objc private func leftDown() { turnLeft = true }
    @objc private func rightDown() { turnRight = true }
    @objc private func pulseDown() { pulseRequested = true }

    @objc private func controlUp(_ sender: UIButton) {
        switch sender.tag {
        case 0: moveForward = false
        case 1: moveBackward = false
        case 2: turnLeft = false
        case 3: turnRight = false
        case 4: pulseRequested = false
        default: break
        }
    }

    @objc private func update() {
        let dt = Float(displayLink?.duration ?? (1.0 / 60.0))
        var direction: Float = 0
        if moveForward { direction += 1 }
        if moveBackward { direction -= 1 }

        var rotation: Float = 0
        if turnLeft { rotation += 1 }
        if turnRight { rotation -= 1 }

        vehicle.eulerAngles.y += rotation * turnSpeed * dt

        if direction != 0 {
            // SceneKit's forward direction is negative Z.
            let yaw = vehicle.eulerAngles.y
            let dx = -sin(yaw) * direction * speed * dt
            let dz = -cos(yaw) * direction * speed * dt
            vehicle.position.x += dx
            vehicle.position.z += dz
        }

        if pulseRequested {
            pulseRequested = false
            launchPulse()
        }

        updateCamera(snap: false)
    }


    private func launchPulse() {
        // Harmless arcade-style energy pulse for the prototype.
        let pulse = SCNNode(geometry: SCNSphere(radius: 0.16))
        pulse.geometry?.firstMaterial?.diffuse.contents = UIColor.systemBlue
        pulse.geometry?.firstMaterial?.emission.contents = UIColor.systemBlue

        let yaw = vehicle.eulerAngles.y
        let start = SCNVector3(
            vehicle.position.x - sin(yaw) * 2.0,
            vehicle.position.y + 1.0,
            vehicle.position.z - cos(yaw) * 2.0
        )
        pulse.position = start
        scene.rootNode.addChildNode(pulse)

        let travel: Float = 22.0
        let end = SCNVector3(
            start.x - sin(yaw) * travel,
            start.y,
            start.z - cos(yaw) * travel
        )
        let move = SCNAction.move(to: end, duration: 1.0)
        pulse.runAction(SCNAction.sequence([move, SCNAction.removeFromParentNode()]))
    }

    private func updateCamera(snap: Bool) {
        let yaw = vehicle.eulerAngles.y
        let distance: Float = 10
        let height: Float = 7
        let target = vehicle.position
        let desired = SCNVector3(
            target.x + sin(yaw) * distance,
            target.y + height,
            target.z + cos(yaw) * distance
        )

        if snap {
            camera.position = desired
        } else {
            let factor: Float = 0.14
            camera.position.x += (desired.x - camera.position.x) * factor
            camera.position.y += (desired.y - camera.position.y) * factor
            camera.position.z += (desired.z - camera.position.z) * factor
        }

        let lookAt = SCNLookAtConstraint(target: vehicle)
        lookAt.isGimbalLockEnabled = true
        camera.constraints = [lookAt]
    }
}
