# Tank3D Continuous Controls

A simple SceneKit 3D vehicle prototype for iOS.

Controls:
- ▲ / ▼: move forward/backward while held
- ◀ / ▶: turn while held
- ✦: launch a harmless arcade-style energy pulse

The pulse is a simple visual projectile with no damage or weapon simulation.
